following are sample pictures of TIM2.

i16.tm2       16bit RGBA DirectColor
i24.tm2       24bit RGB DirectColor
i32.tm2       32bit RGBA DirectColor
i4c16.tm2     4bit IndexColor, 16bit RGBA CLUT
i4c24.tm2     4bit IndexColor, 24bit RGB CLUT
i4c32.tm2     4bit IndexColor, 32bit RGBA CLUT
i8c16.tm2     8bit IndexColor, 16bit RGBA CLUT
i8c24.tm2     8bit IndexColor, 24bit RGB CLUT
i8c32.tm2     8bit IndexColor, 32bit RGBA CLUT
i8c32al.tm2   8bit IndexColor, 32bit RGBA CLUT, 128Byte Align
i8c32cm2.tm2  8bit IndexColor, 32bit RGBA CLUT, CSM2 mode

